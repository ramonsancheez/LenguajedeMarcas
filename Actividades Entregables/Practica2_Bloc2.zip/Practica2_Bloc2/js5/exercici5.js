function enllaços() {

    let enllaços = document.getElementsByTagName("a");
    let google = "google";
    let contadorGoogles = 0
    for (let i = 0; i < enllaços.length; i++) {
        const element = enllaços[i];
        if (element.href.includes(google)) {
            contadorGoogles++;
        }
    }
    alert(enllaços.length + "\n" + enllaços[enllaços.length-1] + "\n" + contadorGoogles);
}