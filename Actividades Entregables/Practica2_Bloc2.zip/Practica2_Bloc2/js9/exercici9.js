function dates() {
    let usuari = crearUsuari();
    afegirUsuari(usuari);
}

function crearUsuari() {
    let formulari = document.getElementById("deportistes");

    let usuari = {};

    let datosAGuardar = ["nom", "edat", "esport", "colorCamiseta", "anyComençament"];

    for (const item of datosAGuardar) {
        
        if (formulari[item].value == "") {
            alert("Introdueix tota la informació possible");
            throw "No s'han introduit dates a totes les casilles possibles";
        }

        if (item == "anyComençament") {
            let data = new Date(formulari[item].value);
            usuari[item] = data.toLocaleDateString();
        }
        usuari[item] = formulari[item].value;
    }
    return usuari;
}

function afegirUsuari(usuari) {
    let idSection = "section" + usuari.esport;

    let section = document.getElementById(idSection);

    if (section == null) {
        section = crearSection(section, idSection, usuari);
    }

    let llista = section.getElementsByTagName("ul")[0];

    let itemLista = document.createElement("li");
    let informacioUsuari = usuari.nom.charAt(0).toUpperCase() + usuari.nom.slice(1) + ", " + usuari.edat + " anys, color camiseta " + usuari.colorCamiseta + ", " + usuari.anyComençament;
    itemLista.appendChild(document.createTextNode(informacioUsuari));

    llista.appendChild(itemLista);
}

function crearSection(section, idSection, usuari) {
    section = document.createElement("section");
    section.id = idSection;

    let tituloSection = document.createElement("h2");
    tituloSection.appendChild(document.createTextNode(usuari.esport));
    section.appendChild(tituloSection);

    let llista = document.createElement("ul");
    section.appendChild(llista);

    let bodyHTML = document.getElementsByTagName("body")[0];
    bodyHTML.appendChild(section);
    return section;
}
