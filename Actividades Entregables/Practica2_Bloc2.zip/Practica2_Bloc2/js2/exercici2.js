function cotxe() {
    var tipusCotxe = prompt("Escriu un tipus de cotxe (Citroen/Audi/Ford/Seat): ");
    var descompte = 0;
    switch (tipusCotxe) {
        case "Citroen":
            descompte = 0.94;
            break;
        case "Audi":
            descompte = 0.96;
            break;
        case "Ford":
            descompte = 0.9;
            break;
        case "Seat":
            descompte = 0.92;
            break;
        default:
            alert("El cotxe no és correcte.")
            exit();
        }
    var preu = prompt("Quant val el cotxe?: ")
    alert(preu*descompte);
}