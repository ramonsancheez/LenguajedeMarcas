function cadenes() {
    var cadena = prompt("Escriu una cadena: ")
    function minuscula(){
        var min = cadena.toLocaleLowerCase();
        return min;
    }
    function majuscula() {
        var maj = cadena.toLocaleUpperCase();
        return maj;
    }
    function restantLetters() {
        var left = cadena.substring(0, cadena.length -5);
        return left;
    }
    function split() {
        var array = cadena.split("");
        return JSON.stringify(array);
        // var i = 0
        // while (i < array.length) {
        //     console.log(array[i]);
        //     i++;
        // }
        // Amb això podríem recorrer l'array i mostrar-ho per consola
    }
    
    alert(minuscula() + "\n" + majuscula() + "\n" + restantLetters() + "\n" + split());
}