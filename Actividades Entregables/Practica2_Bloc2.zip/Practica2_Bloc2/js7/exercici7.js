function amaga() {
    let img = document.getElementsByTagName("img");
    img[0].style.display = "none";
}
function mostra() {
    let img = document.getElementsByTagName("img");
    img[0].style.display = "block";
}
function mesPetit() {
    let img = document.getElementsByTagName("img");
    img[0].width = 34;
}
function mesGran() {
    let img = document.getElementsByTagName("img");
    img[0].width = 1000;
}



