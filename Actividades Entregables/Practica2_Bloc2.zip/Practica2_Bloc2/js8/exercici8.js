function cambiarFondo(colors) {

    colorFons = "white";

    switch (colors) {
        case "blanc":
            colorFons = "white";
            break;
        case "blau":
            colorFons = "blue";
            break;
        case "marron":
            colorFons = "brown";
            break;
        case "taronja":
            colorFons = "orange";
            break;
        case "vermell":
            colorFons = "red";
            break;
        case "verd":
            colorFons = "green";
            break;
    }
    let bodyHTML = document.getElementsByTagName("body")[0];
    bodyHTML.style.backgroundColor = colorFons;
}