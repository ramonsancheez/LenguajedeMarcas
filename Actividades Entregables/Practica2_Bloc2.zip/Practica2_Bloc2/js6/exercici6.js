function p1() {
    let enllaços = document.getElementsByTagName("p");
    let enllaçosArray = Array.from(enllaços);
    enllaçosArray.forEach(element =>
        element.style.display = "block"
    );

}