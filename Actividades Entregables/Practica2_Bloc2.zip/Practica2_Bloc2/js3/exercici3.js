function edat() {
    var edat = prompt("Escriu la teva edat: ");
    if (edat >= 16) {
        document.write("http://www.caib.es")
    } else {
        alert("No tens l'edat suficient.")
    }
}