function ordenador() {
    var nums = prompt("Escriu deu números separats per comes: ");
    var array = nums.split(",");
    array.sort(function (a, b) {
        return a - b;
    });
    alert(array);
}